# Validación de los ajustes UML y de la memoria

Revisión preparada conforme a las indicaciones del tutor y a la estructura de
la plantilla TFM de la Universidad de Almería.

- (a) Las asociaciones actor--caso de uso de las fuentes PlantUML usan líneas sin punta de flecha. Las generalizaciones y dependencias `include`/`extend` conservan su notación UML.
- (b) Existe el actor genérico `Usuario de gestión`; Superadministrador y Gestor de censo heredan directamente de él. `Usuario con auditoría` hereda de `Usuario de gestión`, y Administrador y Auditor heredan de `Usuario con auditoría`.
- (c) RF-13a está incluido desde RF-07 y se documenta como comportamiento obligatorio al cierre. RF-13b es independiente.
- (d) El RF-05 de la especificación se desglosa en RF-05a (SSO de gestión) y RF-05b (SSO de votante). El proveedor de identidad participa en ambos; RF-05b no se incorpora a RF-08.
- (e) RF-10 y RF-11 extienden RF-09 y no tienen asociación directa con Votante. El punto de extensión queda tras confirmar la emisión.
- (f) RF-19 solo tiene asociación con `Usuario con auditoría`, especialización de gestión cuyos subtipos son Administrador y Auditor.
- (g) RNF-8 y RNF-10 se declaran transversales a RF-01--RF-19 y a todas las pantallas, sin asociarlos a un caso de uso concreto.
- (h) La tabla `tab:rnf-iso25010` incluye los 18 RNF y asigna a cada uno características y subcaracterísticas del modelo ISO/IEC 25010:2023.

Las fuentes editables están en `Figuras/diagramas/casos_uso_gestion.puml`,
`Figuras/diagramas/casos_uso_votacion.puml`,
`Figuras/diagramas/secuencia_emitir_voto_recibo.puml` y
`Figuras/diagramas/escrutinio_verificacion_actividad.puml`. Los diagramas de
secuencia y actividad se incluyen en el capítulo 3; los de casos de uso, en el
capítulo 6.

La introducción incorpora preguntas de investigación, objetivos específicos,
trazabilidad, metodología DSR, plan de evaluación, delimitación y amenazas a la
validez. Los catálogos de RF y RNF muestran prioridad MoSCoW explícita o
«Por validar». El Gantt amplía la altura entre filas y deja separación entre
fases; los hitos y las fechas se conservan.
