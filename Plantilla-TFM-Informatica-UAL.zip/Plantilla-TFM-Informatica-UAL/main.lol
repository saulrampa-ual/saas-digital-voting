\contentsline {lstlisting}{\numberline {A.1}{\ignorespaces Fuente PlantUML de gestión y configuración.}}{56}{lstlisting.Alph1.1}%
\contentsline {lstlisting}{\numberline {A.2}{\ignorespaces Fuente PlantUML de participación y verificación.}}{57}{lstlisting.Alph1.2}%
\contentsline {lstlisting}{\numberline {A.3}{\ignorespaces Fuente PlantUML de secuencia para emitir y verificar el recibo.}}{58}{lstlisting.Alph1.3}%
\contentsline {lstlisting}{\numberline {A.4}{\ignorespaces Fuente PlantUML de actividad para el escrutinio y la verificación.}}{59}{lstlisting.Alph1.4}%
